It compiles with make
I tested the examples on visual studio, but I couldn't get to campus to test display on tux computers.  On remote the tests at least ran
Thanks,
Zach
