Compile with ./make
Run CG_Hw1 with the normal command line arguments.  Please keep the ps file in same directory.  By default it will read the hw1.ps file
I think everything works!  I did mostly develop/test with visual studio/windows, but everything seems to be compiling and running fine.
Thanks,
Zach
