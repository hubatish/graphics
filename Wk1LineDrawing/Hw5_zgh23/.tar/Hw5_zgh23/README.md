Compile with make
Small errors have started piling up now.  There's a problem with drawing lines at the top of polygons that's now very obvious.  Front face clipping mostly works.  My z shading works like a line rather than a curve because I missed Breen's lecture and used a simple scaling instead of his formula.  Also I think the rabbit in some of the pictures must be rotated - mine looks like the rabbit in hw5_e (ie flat) in all of the pictures.  Also I didn't really get parallel working for depth 
Thanks,
Zach
