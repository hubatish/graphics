Compile with make
I tested all the examples as typed; they seem to work!
Thanks,
Zach
